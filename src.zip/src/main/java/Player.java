import java.util.HashMap;

public class Player {

    private String name;

    public Player(String name) {
        this.name = name;

    }

    public String getName() {
        return name;
    }

    public Choice choose() {
        Choice result = null;
        return result;
    }
}
