import java.util.Arrays;
import java.util.HashSet;

public class Initialization {

    final public static HashSet<Choice> CHOICES = new HashSet<Choice>(Arrays.asList(Choice.values()));

    public static void initialize() {


    }
}
