import java.util.Arrays;
import java.util.HashSet;

public class Main {


    public static void main(String[] args) {


        Initialization.initialize();

    }
}
